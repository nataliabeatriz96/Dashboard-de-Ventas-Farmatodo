export const firebaseConfig = {
  apiKey: "AIzaSyDUeBm3sTbF6v6Gt2BF5O8ZsImFvECzqTQ",
  authDomain: "programa-de-bts.firebaseapp.com",
  projectId: "programa-de-bts",
  storageBucket: "programa-de-bts.firebasestorage.app",
  messagingSenderId: "763987014680",
  appId: "1:763987014680:web:048d220c4f07548e75ff6d"
};
