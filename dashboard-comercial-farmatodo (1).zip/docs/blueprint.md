# **App Name**: Dashboard Comercial Farmatodo

## Core Features:

- Overview Dashboard Display: A single-page web application featuring a persistent top navigation bar and an 'Overview' tab to present key sales metrics and visualizations.
- Dynamic Data Filtering: Interactive filters (USD/Units toggle, cascading dropdowns for Head, Division, Grupo, Departamento, Clase, Subclase, Proveedor) that dynamically populate from Firestore data and control all displayed KPIs and charts.
- Key Performance Indicator (KPI) Cards: Four KPI cards displaying 'Venta Total Últimos 6 Meses', 'Venta Total Año Móvil', 'Promedio Mensual U6M', and 'Venta Último Mes', with calculated percentage variations and color-coded status.
- Interactive Sales Charts: Dynamic charts including 'Evolución de Ventas' (line, 24 months), 'Top 10 Proveedores' (line, 12 months), 'Top 10 Productos' (bar), 'Ventas por División' (donut), and 'Ventas por Grupo' (bar), all responsive to selected filters.
- Sales Data Upload Tool: A dedicated page accessible from the navigation bar for uploading monthly sales CSV files, ensuring data de-duplication using SKU and Fecha_Mes as document IDs.
- Sales Insights Tool: A generative AI tool that analyzes current KPI values and historical trends, providing textual commentary and actionable insights for key sales performance drivers.

## Style Guidelines:

- Header background: Dark corporate blue (#1E3A6E), as specified in the prompt, providing a professional and commanding presence.
- Primary accent color: A rich, deep blue (#2768DB) to highlight interactive elements, main text, and calls to action, maintaining a corporate and trustworthy feel against a light background.
- Background color: A subtle, near-white shade with a hint of blue (#F8F9FA), chosen to ensure clarity and make the 'white cards' stand out gently with their shadows, consistent with the corporate aesthetic.
- Secondary accent color: A refreshing and clear aqua (#26C5DB) for secondary highlights, loading indicators, or to draw attention to supplementary information, analogous to the primary blue but with a distinct tone.
- Body and headline font: 'Inter' (sans-serif), chosen for its modern, clean, and objective aesthetic, ensuring optimal readability and a professional appearance for data-heavy content and labels.
- Use a set of clean, minimalist, and universally recognizable icons to represent actions, filters, and KPI statuses (e.g., up/down arrows for variations, currency symbols), consistent with a corporate design.
- A single-page, responsive layout featuring a fixed top navigation bar, persistent filters, a four-column grid for KPI cards, and dynamic chart visualizations arranged below, with 'white cards' and subtle shadows for definition.
- Subtle and functional animations for transitions, data loading, filter applications, and chart updates to enhance user experience without distracting from the data.